const express = require("express");
const sql = require("mssql");

const app = express();

app.use(express.json());

const config = {
  user: "haloaxel",
  password: "frijoles",
  server: "LAPTOP-ALAN\\SQLEXPRESS",
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

app.get("/", (req, res) => {
  res.send("API is running");
});

// EXTRAE TODOS LOS CASOS DE COVID-19
app.get("/casos/todo", async (req, res) => {
  try {
    await sql.connect(config);
    const result = await sql.query(
      "SELECT TOP 1000 * FROM covidHistorico.dbo.datoscovid;"
    );
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CASOS DE COVID-19 CON DIABETES
app.get("/casos/diabetes", async (req, res) => {
  try {
    await sql.connect(config);
    const result = await sql.query(
      "SELECT TOP 1000 * FROM covidHistorico.dbo.datoscovid WHERE DIABETES = 1;"
    );
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CASOS DE COVID-19 CON HIPERTENSIÓN
app.get("/casos/hipertension", async (req, res) => {
  try {
    await sql.connect(config);
    const result = await sql.query(
      "SELECT TOP 1000 * FROM covidHistorico.dbo.datoscovid WHERE HIPERTENSION = 1;"
    );
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CASOS POR ENTIDAD (POST)
app.post("/casos/entidades", async (req, res) => {
  const { idEntidad } = req.body;
  try {
    await sql.connect(config);
    const result =
      await sql.query`EXEC covidHistorico.dbo.expo @entidad = ${idEntidad.join(
        ","
      )};`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CASOS POR ENTIDAD (GET)
app.get("/casos/entidades", async (req, res) => {
  const { idEntidad } = req.query;
  try {
    await sql.connect(config);
    const result =
      await sql.query`EXEC covidHistorico.dbo.expo @entidad1 = ${idEntidad};`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
